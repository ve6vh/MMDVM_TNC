/*
 * tasks.h
 *
 *  Created on: Aug 14, 2025
 *      Author: MartinA
 */

#ifndef INC_TASKS_H_
#define INC_TASKS_H_

#ifdef __cplusplus
#define EXTERNC extern "C"
#else
#define EXTERNC
#endif

// task delays
#define	MMDVM_TASK_DELAY		5				// MMDVM task 5 ms

// mmdvm task
EXTERNC void MMDVM_Init(void);
EXTERNC void MMDVM_Exec(void);

EXTERNC void MMDVM_Sample_Interrupt(void);


#endif /* INC_TASKS_H_ */
